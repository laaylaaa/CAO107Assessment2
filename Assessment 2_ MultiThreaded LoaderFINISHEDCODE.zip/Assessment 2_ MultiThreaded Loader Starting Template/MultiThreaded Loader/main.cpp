// Layla Darwiche 
// CAO107 
// Assessment 2
#include <Windows.h>
#include <vector>
#include <thread>
#include <mutex>
#include <string>
#include "resource.h"

#define WINDOW_CLASS_NAME L"MultiThreaded Loader Tool"
// for the window stuff 
const unsigned int _kuiWINDOWWIDTH = 1200;
const unsigned int _kuiWINDOWHEIGHT = 700;
#define MAX_FILES_TO_OPEN 50
#define MAX_CHARACTERS_IN_FILENAME 25

//Global Variables
// DONT NEED SOUND 
// Gets called when we press the button for load image
std::vector<std::wstring> g_vecImageFileNames; // images saved in here. the names of them
std::vector<HBITMAP> g_vecLoadedImages; // hold all the images that have been loaded 
std::vector<std::thread> threadPool;
std::mutex imageLoadLock;
//std::vector<std::wstring> g_vecSoundFileNames;
HINSTANCE g_hInstance; // used with windows dont need to worry 
bool g_bIsFileLoaded = false; // if the file is loaded

void loadingImage(std::wstring filePathName);

//HBITMAP LoaderFile; 
//int threadCount = 3; 
//int yPos, xPos; 
//std::thread* imageThreads = new std::thread[threadCount];
//std::vector<std::thread> vecOfThreads; 

// purpose populate g vec image files 
bool ChooseImageFilesToLoad(HWND _hwnd)
{
	// loads a file and chooses true or false
	// compling list of files in the vector for the images 
	// key function, meant to return true
	OPENFILENAME ofn;
	SecureZeroMemory(&ofn, sizeof(OPENFILENAME)); // Better to use than ZeroMemory
	wchar_t wsFileNames[MAX_FILES_TO_OPEN * MAX_CHARACTERS_IN_FILENAME + MAX_PATH]; //The string to store all the filenames selected in one buffer togther with the complete path name.
	wchar_t _wsPathName[MAX_PATH + 1];
	wchar_t _wstempFile[MAX_PATH + MAX_CHARACTERS_IN_FILENAME]; //Assuming that the filename is not more than 20 characters
	wchar_t _wsFileToOpen[MAX_PATH + MAX_CHARACTERS_IN_FILENAME];
	ZeroMemory(wsFileNames, sizeof(wsFileNames));
	ZeroMemory(_wsPathName, sizeof(_wsPathName));
	ZeroMemory(_wstempFile, sizeof(_wstempFile));

	//Fill out the fields of the structure
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = _hwnd;
	ofn.lpstrFile = wsFileNames;
	ofn.nMaxFile = MAX_FILES_TO_OPEN * 20 + MAX_PATH;  //The size, in charactesr of the buffer pointed to by lpstrFile. The buffer must be atleast 256(MAX_PATH) characters long; otherwise GetOpenFileName and 
													   //GetSaveFileName functions return False
													   // Set lpstrFile[0] to '\0' so that GetOpenFileName does not 
													   // use the contents of wsFileNames to initialize itself.
	ofn.lpstrFile[0] = '\0';
	ofn.lpstrFilter = L"Bitmap Images(.bmp)\0*.bmp\0"; //Filter for bitmap images
	ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;

	//If the user makes a selection from the  open dialog box, the API call returns a non-zero value
	if (GetOpenFileName(&ofn) != 0) //user made a selection and pressed the OK button
	{
		//Extract the path name from the wide string -  two ways of doing it
		//First way: just work with wide char arrays
		wcsncpy_s(_wsPathName, wsFileNames, ofn.nFileOffset);
		int i = ofn.nFileOffset;
		int j = 0;

		while (true)
		{
			if (*(wsFileNames + i) == '\0')
			{
				_wstempFile[j] = *(wsFileNames + i);
				wcscpy_s(_wsFileToOpen, _wsPathName);
				wcscat_s(_wsFileToOpen, L"\\");
				wcscat_s(_wsFileToOpen, _wstempFile);
				g_vecImageFileNames.push_back(_wsFileToOpen);
				j = 0;
			}
			else
			{
				_wstempFile[j] = *(wsFileNames + i);
				j++;
			}
			if (*(wsFileNames + i) == '\0' && *(wsFileNames + i + 1) == '\0')
			{
				break;
			}
			else
			{
				i++;
			}

		}

		g_bIsFileLoaded = true;
		return true;
	}
	else // user pressed the cancel button or closed the dialog box or an error occured
	{
		return false;
	}

}

/*bool ChooseSoundFilesToLoad(HWND _hwnd)
{
	OPENFILENAME ofn;
	SecureZeroMemory(&ofn, sizeof(OPENFILENAME)); // Better to use than ZeroMemory
	wchar_t wsFileNames[MAX_FILES_TO_OPEN * MAX_CHARACTERS_IN_FILENAME + MAX_PATH]; //The string to store all the filenames selected in one buffer togther with the complete path name.
	wchar_t _wsPathName[MAX_PATH + 1];
	wchar_t _wstempFile[MAX_PATH + MAX_CHARACTERS_IN_FILENAME]; //Assuming that the filename is not more than 20 characters
	wchar_t _wsFileToOpen[MAX_PATH + MAX_CHARACTERS_IN_FILENAME];
	ZeroMemory(wsFileNames, sizeof(wsFileNames));
	ZeroMemory(_wsPathName, sizeof(_wsPathName));
	ZeroMemory(_wstempFile, sizeof(_wstempFile));

	//Fill out the fields of the structure
	ofn.lStructSize = sizeof(OPENFILENAME);
	ofn.hwndOwner = _hwnd;
	ofn.lpstrFile = wsFileNames;
	ofn.nMaxFile = MAX_FILES_TO_OPEN * 20 + MAX_PATH;  //The size, in charactesr of the buffer pointed to by lpstrFile. The buffer must be atleast 256(MAX_PATH) characters long; otherwise GetOpenFileName and
													   //GetSaveFileName functions return False
													   // Set lpstrFile[0] to '\0' so that GetOpenFileName does not
													   // use the contents of wsFileNames to initialize itself.
	ofn.lpstrFile[0] = '\0';
	ofn.lpstrFilter = L"Wave Files (*.wav)\0*.wav\0All Files (*.*)\0*.*\0"; //Filter for wav files
	ofn.Flags = OFN_EXPLORER | OFN_FILEMUSTEXIST | OFN_FILEMUSTEXIST | OFN_ALLOWMULTISELECT;

	//If the user makes a selection from the  open dialog box, the API call returns a non-zero value
	if (GetOpenFileName(&ofn) != 0) //user made a selection and pressed the OK button
	{
		//Extract the path name from the wide string -  two ways of doing it
		//Second way: work with wide strings and a char pointer

		std::wstring _wstrPathName = ofn.lpstrFile;

		_wstrPathName.resize(ofn.nFileOffset, '\\');

		wchar_t *_pwcharNextFile = &ofn.lpstrFile[ofn.nFileOffset];

		while (*_pwcharNextFile)
		{
			std::wstring _wstrFileName = _wstrPathName + _pwcharNextFile;

			g_vecSoundFileNames.push_back(_wstrFileName);

			_pwcharNextFile += lstrlenW(_pwcharNextFile) + 1;
		}

		g_bIsFileLoaded = true;
		return true;
	}
	else // user pressed the cancel button or closed the dialog box or an error occured
	{
		return false;
	}

}*/

// only really need to work here 
// called when we get a message to process 
// so windows can tell us whats going on 
LRESULT CALLBACK WindowProc(HWND _hwnd, UINT _uiMsg, WPARAM _wparam, LPARAM _lparam)
{
	PAINTSTRUCT ps;
	HDC _hWindowDC;
	//RECT rect;
	switch (_uiMsg)
	{
	case WM_KEYDOWN:
	{
		switch (_wparam)
		{
		case VK_ESCAPE:
		{
			SendMessage(_hwnd, WM_CLOSE, 0, 0); // when escape is pressed close the window
			return(0);
		}
		break;
		default:
			break;
		}
	}
	break;
	// when someoneeee is painting stuff on your window 
	// painting means someone is rendering pixels on the screen, "painting pixels"
	case WM_PAINT:
	{
		// search up how to paint 
		_hWindowDC = BeginPaint(_hwnd, &ps);
		//Do all our painting here

		FillRect(_hWindowDC, &ps.rcPaint, (HBRUSH)(COLOR_WINDOW + 1));

		EndPaint(_hwnd, &ps);
		return (0);
	}
	break;
	case WM_COMMAND:
	{
		switch (LOWORD(_wparam))
		{


		case ID_FILE_LOADIMAGE:
		{
			// THIS IS WHERE TO DO THE ASSIGNMENT STUFF
			// work with BMP files 
			if (ChooseImageFilesToLoad(_hwnd))
			{
				//Write code here to create multiple threads to load image files in parallel
				for (int i = 0; i < g_vecImageFileNames.size(); i++) {
					// load the image
					std::wstring imageFileName = g_vecImageFileNames[i]; // string to hold the name of the image
					threadPool.push_back(std::thread(loadingImage, imageFileName)); // adding the loading image thread into the threadpool thread
				}

				// joining every thread within threadpool to the main 
				for (int j = 0; j < threadPool.size(); j++) {

					threadPool[j].join();
				}

				// rendering the images to the windows screen 
				for (int i = 0; i < g_vecImageFileNames.size(); i++) {

					HBITMAP loadedImage = g_vecLoadedImages[i]; // make loaded image equal the image the loop is up to

					//  using a brush prints the images to the screen 
					RECT rect;
					HDC hdc = GetDC(_hwnd); // get the DC ftom the window handle  
					HBRUSH brush = CreatePatternBrush(loadedImage); // create a brush and set it to the loaded image 
					SetRect(&rect, 250 * i, 0, 250 * i + 250, 250); // set the position of the image 
					FillRect(hdc, &rect, brush); 
					// Cleans up, so windows knows we are done with this process 
					DeleteObject(brush);
					ReleaseDC(_hwnd, hdc);
				}

			}
			else
			{
				MessageBox(_hwnd, L"No Image File selected", L"Error Message", MB_ICONWARNING);
			}

			return (0);
		}
		break;
		/*case ID_FILE_LOADSOUND:
		{
			// DONT NEED TO DO UNLESS WANT EXTRA MARRKKKSSSS
			if (ChooseSoundFilesToLoad(_hwnd))
			{
				//Write code here to create multiple threads to load sound files in parallel
			}
			else
			{
				MessageBox(_hwnd, L"No Sound File selected", L"Error Message", MB_ICONWARNING);
			}
			return (0);
		}
		break;*/
		case ID_EXIT:
		{
			SendMessage(_hwnd, WM_CLOSE, 0, 0);
			return (0);
		}
		break;
		default:
			break;
		}
	}
	break;
	case WM_CLOSE:
	{
		PostQuitMessage(0);
	}
	break;
	default:
		break;
	}
	return (DefWindowProc(_hwnd, _uiMsg, _wparam, _lparam));
}

void loadingImage(std::wstring filePathName) {

	HBITMAP loadedImage = (HBITMAP)LoadImageW(NULL, filePathName.c_str(), IMAGE_BITMAP, 250, 250, LR_LOADFROMFILE);

	imageLoadLock.lock(); // ensures only one thread is going into do the push back at a time 
	g_vecLoadedImages.push_back(loadedImage);
	imageLoadLock.unlock();
}

HWND CreateAndRegisterWindow(HINSTANCE _hInstance)
{
	WNDCLASSEX winclass; // This will hold the class we create.
	HWND hwnd;           // Generic window handle.

						 // First fill in the window class structure.
	winclass.cbSize = sizeof(WNDCLASSEX);
	winclass.style = CS_DBLCLKS | CS_OWNDC | CS_HREDRAW | CS_VREDRAW;
	winclass.lpfnWndProc = WindowProc;
	winclass.cbClsExtra = 0;
	winclass.cbWndExtra = 0;
	winclass.hInstance = _hInstance;
	winclass.hIcon = LoadIcon(NULL, IDI_APPLICATION);
	winclass.hCursor = LoadCursor(NULL, IDC_ARROW);
	winclass.hbrBackground =
		static_cast<HBRUSH>(GetStockObject(WHITE_BRUSH));
	winclass.lpszMenuName = NULL;
	winclass.lpszClassName = WINDOW_CLASS_NAME;
	winclass.hIconSm = LoadIcon(NULL, IDI_APPLICATION);

	// register the window class
	if (!RegisterClassEx(&winclass))
	{
		return (0);
	}

	HMENU _hMenu = LoadMenu(_hInstance, MAKEINTRESOURCE(IDR_MENU1));

	// create the window
	hwnd = CreateWindowEx(NULL, // Extended style.
		WINDOW_CLASS_NAME,      // Class.
		L"MultiThreaded Loader Tool",   // Title.
		WS_OVERLAPPEDWINDOW | WS_VISIBLE,
		10, 10,                    // Initial x,y.
		_kuiWINDOWWIDTH, _kuiWINDOWHEIGHT,                // Initial width, height.
		NULL,                   // Handle to parent.
		_hMenu,                   // Handle to menu.
		_hInstance,             // Instance of this application.
		NULL);                  // Extra creation parameters.

	return hwnd;
}



int WINAPI WinMain(HINSTANCE _hInstance,
	HINSTANCE _hPrevInstance,
	LPSTR _lpCmdLine,
	int _nCmdShow)
{
	MSG msg;  //Generic Message

	HWND _hwnd = CreateAndRegisterWindow(_hInstance); // handle

	if (!(_hwnd)) // if handle is empty return 0
	{
		return (0);
	}


	// Enter main event loop
	while (true)
	{
		// Test if there is a message in queue, if so get it.
		if (PeekMessage(&msg, NULL, 0, 0, PM_REMOVE)) // peak message, if there is an event there will be a message
		{
			// Test if this is a quit.
			if (msg.message == WM_QUIT)
			{
				//  can create a message box to pop up when exitting 
				break;// if quit, exit 
			}

			// Translate any accelerator keys.
			TranslateMessage(&msg);
			// Send the message to the window proc.
			DispatchMessage(&msg);
		}

	}

	// Return to Windows like this...
	return (static_cast<int>(msg.wParam));
}

//// loads the images 
//void Controller(HWND wnd, int ImageNo) {
//	//g_Lock.lock(); 
//
//	if (yPos > 0) {
//		xPos = ((ImageNo - 8) * 100);
//	}
//	else {
//		xPos = ImageNo * 100; 
//	}
//
//	if (xPos >= _kuiWINDOWHEIGHT) {
//		yPos += 100; 
//		xPos = 0; 
//	}
//
//	wnd = CreateWindow(L"STATIC", NULL, WS_VISIBLE | WS_CHILD | SS_BITMAP, xPos, yPos, 0, 0, wnd, NULL, NULL, NULL); 
//	//g_Lock.unlock(); 
//	SendMessage(wnd, STM_SETIMAGE, IMAGE_BITMAP, (LPARAM)LoaderFile); 
//}